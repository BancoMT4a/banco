module.exports = {
    auth_api_url: 'https://auth-ms-mt.herokuapp.com',
    account_api_url: 'https://account-ms-mt.herokuapp.com',
};