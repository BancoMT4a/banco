package com.misiontic.account_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
